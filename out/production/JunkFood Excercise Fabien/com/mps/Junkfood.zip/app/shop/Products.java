package com.mps.app.shop;

public enum Products {

    HamBurger,
    ChickenBurger,
    HawaiiBurger,
    KangarooBurger,
    FishBurger,



}
